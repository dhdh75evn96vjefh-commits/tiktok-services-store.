import { describe, it, expect, beforeEach, vi } from 'vitest';
import { 
  getAllServices, 
  getServiceById, 
  upsertService,
  getAllOrders,
  createOrder,
  updateOrderStatus,
  getActiveOffers,
} from './db';

describe('Services and Orders Database Functions', () => {
  describe('Services', () => {
    it('should retrieve all services', async () => {
      const services = await getAllServices();
      expect(Array.isArray(services)).toBe(true);
    });

    it('should upsert a service', async () => {
      const newService = {
        name: 'متابعون حقيقيون',
        description: 'احصل على 100 متابع حقيقي',
        category: 'followers',
        price: 50,
        minQuantity: 10,
        maxQuantity: 1000,
        unit: 'متابع',
        googleSheetRow: 1,
      };

      const result = await upsertService(newService);
      expect(result).toBeDefined();
      expect(result.name).toBe(newService.name);
      expect(result.price).toBe(newService.price);
    });

    it('should get a service by ID', async () => {
      const services = await getAllServices();
      if (services.length > 0) {
        const service = await getServiceById(services[0].id);
        expect(service).toBeDefined();
        expect(service?.id).toBe(services[0].id);
      }
    });
  });

  describe('Orders', () => {
    it('should retrieve all orders', async () => {
      const orders = await getAllOrders();
      expect(Array.isArray(orders)).toBe(true);
    });

    it('should create an order', async () => {
      const services = await getAllServices();
      if (services.length === 0) {
        // Create a test service first
        await upsertService({
          name: 'اختبار - متابعون',
          description: 'خدمة اختبار',
          category: 'followers',
          price: 100,
          minQuantity: 1,
          maxQuantity: 1000,
          unit: 'متابع',
          googleSheetRow: 999,
        });
      }

      const servicesList = await getAllServices();
      const testService = servicesList[0];

      const newOrder = {
        serviceId: testService.id,
        customerName: 'أحمد محمد',
        customerEmail: 'ahmed@example.com',
        tiktokLink: 'https://www.tiktok.com/@ahmed',
        quantity: 50,
        totalPrice: 5000,
        status: 'new' as const,
        googleSheetRow: null,
      };

      const result = await createOrder(newOrder as any);
      expect(result).toBeDefined();
      expect(result.customerName).toBe(newOrder.customerName);
      expect(result.quantity).toBe(newOrder.quantity);
      expect(result.status).toBe('new');
    });

    it('should update order status', async () => {
      const orders = await getAllOrders();
      if (orders.length > 0) {
        const order = orders[0];
        const updated = await updateOrderStatus(order.id, 'in_progress');
        
        expect(updated).toBeDefined();
        expect(updated.status).toBe('in_progress');
      }
    });
  });

  describe('Offers', () => {
    it('should retrieve active offers', async () => {
      const offers = await getActiveOffers();
      expect(Array.isArray(offers)).toBe(true);
    });
  });
});
