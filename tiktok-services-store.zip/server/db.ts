import { eq, and, gte, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, services, orders, offers, Service, Order, Offer } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Services queries
export async function getAllServices(): Promise<Service[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get services: database not available");
    return [];
  }

  return await db.select().from(services);
}

export async function getServiceById(id: number): Promise<Service | undefined> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get service: database not available");
    return undefined;
  }

  const result = await db.select().from(services).where(eq(services.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function upsertService(service: Omit<Service, 'id' | 'createdAt' | 'updatedAt'>): Promise<Service> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const existing = await db.select().from(services).where(eq(services.googleSheetRow, service.googleSheetRow)).limit(1);

  if (existing.length > 0) {
    // Update existing
    await db.update(services).set({
      name: service.name,
      description: service.description,
      category: service.category,
      price: service.price,
      minQuantity: service.minQuantity,
      maxQuantity: service.maxQuantity,
      unit: service.unit,
    }).where(eq(services.id, existing[0].id));
    return (await getServiceById(existing[0].id))!;
  } else {
    // Insert new
    const result = await db.insert(services).values(service as any);
    return (await getServiceById(result[0].insertId as number))!;
  }
}

// Orders queries
export async function getAllOrders(): Promise<Order[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get orders: database not available");
    return [];
  }

  return await db.select().from(orders);
}

export async function getOrderById(id: number): Promise<Order | undefined> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get order: database not available");
    return undefined;
  }

  const result = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createOrder(order: Omit<Order, 'id' | 'createdAt' | 'updatedAt'>): Promise<Order> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.insert(orders).values(order as any);
  return (await getOrderById(result[0].insertId as number))!;
}

export async function updateOrderStatus(id: number, status: 'new' | 'in_progress' | 'completed'): Promise<Order> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db.update(orders).set({ status }).where(eq(orders.id, id));
  return (await getOrderById(id))!;
}

export async function updateOrderGoogleSheetRow(id: number, googleSheetRow: number): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db.update(orders).set({ googleSheetRow }).where(eq(orders.id, id));
}

// Offers queries
export async function getAllOffers(): Promise<Offer[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get offers: database not available");
    return [];
  }

  return await db.select().from(offers);
}

export async function getActiveOffers(): Promise<Offer[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get offers: database not available");
    return [];
  }

  const now = new Date();
  return await db.select().from(offers).where(
    and(
      lte(offers.startDate, now),
      gte(offers.endDate, now)
    )
  );
}

export async function upsertOffer(offer: Omit<Offer, 'id' | 'createdAt' | 'updatedAt'>): Promise<Offer> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const existing = await db.select().from(offers).where(eq(offers.googleSheetRow, offer.googleSheetRow)).limit(1);

  if (existing.length > 0) {
    // Update existing
    await db.update(offers).set({
      name: offer.name,
      description: offer.description,
      discountPercentage: offer.discountPercentage,
      serviceId: offer.serviceId,
      startDate: offer.startDate,
      endDate: offer.endDate,
    }).where(eq(offers.id, existing[0].id));
    return (await getOfferById(existing[0].id))!;
  } else {
    // Insert new
    const result = await db.insert(offers).values(offer as any);
    return (await getOfferById(result[0].insertId as number))!;
  }
}

export async function getOfferById(id: number): Promise<Offer | undefined> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get offer: database not available");
    return undefined;
  }

  const result = await db.select().from(offers).where(eq(offers.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}
