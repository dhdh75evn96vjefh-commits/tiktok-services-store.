import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { 
  getAllServices, 
  getActiveOffers, 
  createOrder, 
  getAllOrders, 
  updateOrderStatus,
  updateOrderGoogleSheetRow 
} from "./db";
import { 
  appendOrderToSheet, 
  updateOrderStatusInSheet,
  syncServicesFromSheet,
  syncOffersFromSheet
} from "./googleSheets";
import { notifyOwner } from "./_core/notification";
import { ENV } from "./_core/env";

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Services endpoints
  services: router({
    list: publicProcedure.query(async () => {
      return await getAllServices();
    }),

    syncFromSheet: protectedProcedure.mutation(async ({ ctx }) => {
      // Only admin can sync
      if (ctx.user?.role !== 'admin') {
        throw new Error('Unauthorized');
      }

      if (!ENV.googleSheetsSpreadsheetId) {
        throw new Error('Google Sheets Spreadsheet ID not configured');
      }

      try {
        const servicesCount = await syncServicesFromSheet(ENV.googleSheetsSpreadsheetId, 'Services');
        const offersCount = await syncOffersFromSheet(ENV.googleSheetsSpreadsheetId, 'Offers');
        
        return {
          success: true,
          servicesCount,
          offersCount,
        };
      } catch (error) {
        console.error('Failed to sync from sheet:', error);
        throw error;
      }
    }),
  }),

  // Offers endpoints
  offers: router({
    list: publicProcedure.query(async () => {
      return await getActiveOffers();
    }),
  }),

  // Orders endpoints
  orders: router({
    create: publicProcedure
      .input(z.object({
        serviceId: z.number(),
        customerName: z.string().min(1),
        customerEmail: z.string().email(),
        tiktokLink: z.string().url(),
        quantity: z.number().min(1),
      }))
      .mutation(async ({ input }) => {
        try {
          // Get service details
          const { getServiceById } = await import('./db');
          const service = await getServiceById(input.serviceId);
          
          if (!service) {
            throw new Error('Service not found');
          }

          // Calculate total price
          const totalPrice = service.price * input.quantity;

          // Create order in database
          const order = await createOrder({
            serviceId: input.serviceId,
            customerName: input.customerName,
            customerEmail: input.customerEmail,
            tiktokLink: input.tiktokLink,
            quantity: input.quantity,
            totalPrice,
            status: 'new',
            googleSheetRow: null,
          } as any);

          // Append to Google Sheets if configured
          if (ENV.googleSheetsSpreadsheetId) {
            try {
              const sheetResult = await appendOrderToSheet(
                ENV.googleSheetsSpreadsheetId,
                {
                  id: order.id,
                  serviceName: service.name,
                  customerName: input.customerName,
                  customerEmail: input.customerEmail,
                  tiktokLink: input.tiktokLink,
                  quantity: input.quantity,
                  totalPrice,
                  status: 'new',
                  createdAt: order.createdAt,
                },
                'Orders'
              );

              // Update order with Google Sheet row
              if (sheetResult.googleSheetRow) {
                await updateOrderGoogleSheetRow(order.id, sheetResult.googleSheetRow);
              }
            } catch (sheetError) {
              console.error('Failed to append order to sheet:', sheetError);
              // Don't fail the order creation if sheet sync fails
            }
          }

          // Send notification to owner
          try {
            await notifyOwner({
              title: 'طلب جديد من متجر التيك توك',
              content: `تم استقبال طلب جديد من ${input.customerName}\\nالخدمة: ${service.name}\\nالكمية: ${input.quantity}\\nالسعر الإجمالي: ${totalPrice}`,
            });
          } catch (notifyError) {
            console.error('Failed to send notification:', notifyError);
            // Don't fail the order creation if notification fails
          }

          return {
            success: true,
            orderId: order.id,
            totalPrice,
          };
        } catch (error) {
          console.error('Failed to create order:', error);
          throw error;
        }
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      // Only admin can view all orders
      if (ctx.user?.role !== 'admin') {
        throw new Error('Unauthorized');
      }

      return await getAllOrders();
    }),

    updateStatus: protectedProcedure
      .input(z.object({
        orderId: z.number(),
        status: z.enum(['new', 'in_progress', 'completed']),
      }))
      .mutation(async ({ input, ctx }) => {
        // Only admin can update order status
        if (ctx.user?.role !== 'admin') {
          throw new Error('Unauthorized');
        }

        try {
          const { getOrderById } = await import('./db');
          const order = await getOrderById(input.orderId);

          if (!order) {
            throw new Error('Order not found');
          }

          // Update in database
          const updatedOrder = await updateOrderStatus(input.orderId, input.status);

          // Update in Google Sheets if configured
          if (ENV.googleSheetsSpreadsheetId && order.googleSheetRow) {
            try {
              await updateOrderStatusInSheet(
                ENV.googleSheetsSpreadsheetId,
                order.googleSheetRow,
                input.status,
                'Orders'
              );
            } catch (sheetError) {
              console.error('Failed to update order status in sheet:', sheetError);
              // Don't fail the status update if sheet sync fails
            }
          }

          return {
            success: true,
            order: updatedOrder,
          };
        } catch (error) {
          console.error('Failed to update order status:', error);
          throw error;
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
