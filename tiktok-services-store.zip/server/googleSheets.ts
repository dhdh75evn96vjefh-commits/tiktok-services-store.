import { google } from 'googleapis';
import { GoogleAuth } from 'google-auth-library';
import { ENV } from './_core/env';

/**
 * Google Sheets API Integration
 * 
 * This module handles all interactions with Google Sheets for:
 * - Fetching services, prices, and offers
 * - Saving orders
 * - Updating order statuses
 */

let sheetsClient: any = null;

/**
 * Initialize Google Sheets client with service account credentials
 * Credentials should be provided via environment variables:
 * - GOOGLE_SHEETS_PRIVATE_KEY
 * - GOOGLE_SHEETS_CLIENT_EMAIL
 * - GOOGLE_SHEETS_PROJECT_ID
 */
export async function initializeGoogleSheets() {
  if (sheetsClient) return sheetsClient;

  const privateKey = ENV.googleSheetsPrivateKey?.replace(/\\n/g, '\n');
  const clientEmail = ENV.googleSheetsClientEmail;
  const projectId = ENV.googleSheetsProjectId;

  if (!privateKey || !clientEmail || !projectId) {
    console.warn('[GoogleSheets] Missing credentials. Set GOOGLE_SHEETS_PRIVATE_KEY, GOOGLE_SHEETS_CLIENT_EMAIL, and GOOGLE_SHEETS_PROJECT_ID');
    return null;
  }

  try {
    const auth = new GoogleAuth({
      credentials: {
        type: 'service_account',
        project_id: projectId,
        private_key_id: '',
        private_key: privateKey,
        client_email: clientEmail,
        client_id: '',
      } as any,
      scopes: ['https://www.googleapis.com/auth/spreadsheets'],
    });

    sheetsClient = google.sheets({ version: 'v4', auth });
    console.log('[GoogleSheets] Client initialized successfully');
    return sheetsClient;
  } catch (error) {
    console.error('[GoogleSheets] Failed to initialize client:', error);
    return null;
  }
}

/**
 * Fetch services from Google Sheets
 * Expected sheet structure:
 * Row 1: Headers (Name, Description, Category, Price, MinQuantity, MaxQuantity, Unit)
 * Row 2+: Service data
 */
export async function fetchServicesFromSheet(spreadsheetId: string, sheetName: string = 'Services') {
  const client = await initializeGoogleSheets();
  if (!client) throw new Error('Google Sheets client not initialized');

  try {
    const response = await client.spreadsheets.values.get({
      spreadsheetId,
      range: `${sheetName}!A2:H`,
    });

    const rows = response.data.values || [];
    const services = rows.map((row: any[], index: number) => ({
      name: row[0] || '',
      description: row[1] || '',
      category: row[2] || '',
      price: parseInt(row[3]) || 0,
      minQuantity: parseInt(row[4]) || 1,
      maxQuantity: parseInt(row[5]) || 100000,
      unit: row[6] || 'quantity',
      googleSheetRow: index + 2, // Row number in sheet (1-indexed, +1 for header)
    }));

    return services;
  } catch (error) {
    console.error('[GoogleSheets] Failed to fetch services:', error);
    throw error;
  }
}

/**
 * Fetch offers from Google Sheets
 * Expected sheet structure:
 * Row 1: Headers (Name, Description, DiscountPercentage, ServiceId, StartDate, EndDate)
 * Row 2+: Offer data
 */
export async function fetchOffersFromSheet(spreadsheetId: string, sheetName: string = 'Offers') {
  const client = await initializeGoogleSheets();
  if (!client) throw new Error('Google Sheets client not initialized');

  try {
    const response = await client.spreadsheets.values.get({
      spreadsheetId,
      range: `${sheetName}!A2:F`,
    });

    const rows = response.data.values || [];
    const offers = rows.map((row: any[], index: number) => ({
      name: row[0] || '',
      description: row[1] || '',
      discountPercentage: parseInt(row[2]) || 0,
      serviceId: row[3] ? parseInt(row[3]) : null,
      startDate: new Date(row[4] || new Date()),
      endDate: new Date(row[5] || new Date()),
      googleSheetRow: index + 2,
    }));

    return offers;
  } catch (error) {
    console.error('[GoogleSheets] Failed to fetch offers:', error);
    throw error;
  }
}

/**
 * Append order to Google Sheets
 * Expected sheet structure:
 * Row 1: Headers (OrderID, ServiceName, CustomerName, CustomerEmail, TiktokLink, Quantity, TotalPrice, Status, CreatedAt, UpdatedAt)
 * Row 2+: Order data
 */
export async function appendOrderToSheet(
  spreadsheetId: string,
  order: {
    id: number;
    serviceName: string;
    customerName: string;
    customerEmail: string;
    tiktokLink: string;
    quantity: number;
    totalPrice: number;
    status: string;
    createdAt: Date;
  },
  sheetName: string = 'Orders'
) {
  const client = await initializeGoogleSheets();
  if (!client) throw new Error('Google Sheets client not initialized');

  try {
    const values = [[
      order.id,
      order.serviceName,
      order.customerName,
      order.customerEmail,
      order.tiktokLink,
      order.quantity,
      order.totalPrice,
      order.status,
      order.createdAt.toISOString(),
      new Date().toISOString(),
    ]];

    const response = await client.spreadsheets.values.append({
      spreadsheetId,
      range: `${sheetName}!A:J`,
      valueInputOption: 'USER_ENTERED',
      requestBody: {
        values,
      },
    });

    // Extract the row number from the response
    const updatedRange = response.data.updates?.updatedRange || '';
    const rowMatch = updatedRange.match(/!A(\d+)/);
    const googleSheetRow = rowMatch ? parseInt(rowMatch[1]) : null;

    return { success: true, googleSheetRow };
  } catch (error) {
    console.error('[GoogleSheets] Failed to append order:', error);
    throw error;
  }
}

/**
 * Update order status in Google Sheets
 */
export async function updateOrderStatusInSheet(
  spreadsheetId: string,
  googleSheetRow: number,
  status: string,
  sheetName: string = 'Orders'
) {
  const client = await initializeGoogleSheets();
  if (!client) throw new Error('Google Sheets client not initialized');

  try {
    await client.spreadsheets.values.update({
      spreadsheetId,
      range: `${sheetName}!H${googleSheetRow}`,
      valueInputOption: 'USER_ENTERED',
      requestBody: {
        values: [[status]],
      },
    });

    // Also update the UpdatedAt column
    await client.spreadsheets.values.update({
      spreadsheetId,
      range: `${sheetName}!J${googleSheetRow}`,
      valueInputOption: 'USER_ENTERED',
      requestBody: {
        values: [[new Date().toISOString()]],
      },
    });

    return { success: true };
  } catch (error) {
    console.error('[GoogleSheets] Failed to update order status:', error);
    throw error;
  }
}

/**
 * Sync services from Google Sheets to database
 */
export async function syncServicesFromSheet(spreadsheetId: string, sheetName: string = 'Services') {
  const { upsertService } = await import('./db');
  
  try {
    const services = await fetchServicesFromSheet(spreadsheetId, sheetName);
    
    for (const service of services) {
      await upsertService(service);
    }

    console.log(`[GoogleSheets] Synced ${services.length} services`);
    return services.length;
  } catch (error) {
    console.error('[GoogleSheets] Failed to sync services:', error);
    throw error;
  }
}

/**
 * Sync offers from Google Sheets to database
 */
export async function syncOffersFromSheet(spreadsheetId: string, sheetName: string = 'Offers') {
  const { upsertOffer } = await import('./db');
  
  try {
    const offers = await fetchOffersFromSheet(spreadsheetId, sheetName);
    
    for (const offer of offers) {
      await upsertOffer(offer);
    }

    console.log(`[GoogleSheets] Synced ${offers.length} offers`);
    return offers.length;
  } catch (error) {
    console.error('[GoogleSheets] Failed to sync offers:', error);
    throw error;
  }
}
