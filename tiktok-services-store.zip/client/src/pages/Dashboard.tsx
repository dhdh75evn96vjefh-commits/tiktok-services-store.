import { useAuth } from '@/_core/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { trpc } from '@/lib/trpc';
import { getLoginUrl } from '@/const';
import { Loader2, LogOut } from 'lucide-react';
import { useLocation } from 'wouter';
import { toast } from 'sonner';

export default function Dashboard() {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [, setLocation] = useLocation();

  const ordersQuery = trpc.orders.list.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === 'admin',
  } as any);

  const updateStatusMutation = trpc.orders.updateStatus.useMutation();
  const syncMutation = trpc.services.syncFromSheet.useMutation();

  const orders = ordersQuery.data || [];

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="animate-spin text-pink-500" size={40} />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col justify-center items-center min-h-screen bg-gradient-to-br from-black to-gray-900">
        <Card className="border-gray-700 bg-gray-900 w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle className="text-white">لوحة التحكم</CardTitle>
            <CardDescription>يرجى تسجيل الدخول للوصول إلى لوحة التحكم</CardDescription>
          </CardHeader>
          <CardContent>
            <a href={getLoginUrl()}>
              <Button className="w-full bg-pink-500 hover:bg-pink-600">
                تسجيل الدخول
              </Button>
            </a>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (user?.role !== 'admin') {
    return (
      <div className="flex flex-col justify-center items-center min-h-screen bg-gradient-to-br from-black to-gray-900">
        <Card className="border-gray-700 bg-gray-900 w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle className="text-white">غير مصرح</CardTitle>
            <CardDescription>ليس لديك صلاحية للوصول إلى لوحة التحكم</CardDescription>
          </CardHeader>
          <CardContent>
            <Button 
              onClick={() => setLocation('/')}
              className="w-full bg-gray-700 hover:bg-gray-600"
            >
              العودة إلى المتجر
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleStatusChange = async (orderId: number, newStatus: 'new' | 'in_progress' | 'completed') => {
    try {
      await updateStatusMutation.mutateAsync({
        orderId,
        status: newStatus,
      });
      toast.success('تم تحديث حالة الطلب بنجاح');
      ordersQuery.refetch();
    } catch (error) {
      toast.error('فشل في تحديث حالة الطلب');
      console.error(error);
    }
  };

  const handleSync = async () => {
    try {
      const result = await syncMutation.mutateAsync();
      toast.success(`تم مزامنة ${result.servicesCount} خدمات و ${result.offersCount} عروض`);
    } catch (error) {
      toast.error('فشل في المزامنة من Google Sheets');
      console.error(error);
    }
  };

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      'new': 'جديد',
      'in_progress': 'قيد التنفيذ',
      'completed': 'مكتمل',
    };
    return labels[status] || status;
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      'new': 'bg-blue-500/20 text-blue-400',
      'in_progress': 'bg-yellow-500/20 text-yellow-400',
      'completed': 'bg-green-500/20 text-green-400',
    };
    return colors[status] || 'bg-gray-500/20 text-gray-400';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black">
      {/* Header */}
      <header className="border-b border-gray-800 bg-black/50 backdrop-blur">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <h1 className="text-3xl font-bold text-white">لوحة التحكم</h1>
            <div className="flex items-center gap-4">
              <span className="text-gray-400">{user?.name}</span>
              <Button 
                onClick={logout}
                variant="outline"
                className="border-gray-700 hover:bg-gray-800"
              >
                <LogOut size={18} className="mr-2" />
                تسجيل الخروج
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        {/* Actions */}
        <div className="mb-8 flex gap-4">
          <Button 
            onClick={handleSync}
            disabled={syncMutation.isPending}
            className="bg-pink-500 hover:bg-pink-600"
          >
            {syncMutation.isPending ? (
              <>
                <Loader2 className="animate-spin mr-2" size={18} />
                جاري المزامنة...
              </>
            ) : (
              'مزامنة من Google Sheets'
            )}
          </Button>
        </div>

        {/* Orders Table */}
        <Card className="border-gray-700 bg-gray-900/50">
          <CardHeader>
            <CardTitle className="text-white">الطلبات الواردة</CardTitle>
            <CardDescription>
              إجمالي الطلبات: {orders.length}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {ordersQuery.isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="animate-spin text-pink-500" size={40} />
              </div>
            ) : orders.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                لا توجد طلبات حتى الآن
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="border-gray-700 hover:bg-transparent">
                      <TableHead className="text-gray-300">رقم الطلب</TableHead>
                      <TableHead className="text-gray-300">الخدمة</TableHead>
                      <TableHead className="text-gray-300">العميل</TableHead>
                      <TableHead className="text-gray-300">البريد الإلكتروني</TableHead>
                      <TableHead className="text-gray-300">الكمية</TableHead>
                      <TableHead className="text-gray-300">السعر</TableHead>
                      <TableHead className="text-gray-300">الحالة</TableHead>
                      <TableHead className="text-gray-300">التاريخ</TableHead>
                      <TableHead className="text-gray-300">الإجراء</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {orders.map((order) => (
                      <TableRow key={order.id} className="border-gray-700 hover:bg-gray-800/50">
                        <TableCell className="text-white font-bold">#{order.id}</TableCell>
                        <TableCell className="text-gray-300">{order.serviceId}</TableCell>
                        <TableCell className="text-gray-300">{order.customerName}</TableCell>
                        <TableCell className="text-gray-300 text-sm">{order.customerEmail}</TableCell>
                        <TableCell className="text-gray-300">{order.quantity}</TableCell>
                        <TableCell className="text-pink-400 font-bold">{order.totalPrice}</TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded text-xs font-bold ${getStatusColor(order.status)}`}>
                            {getStatusLabel(order.status)}
                          </span>
                        </TableCell>
                        <TableCell className="text-gray-400 text-sm">
                          {new Date(order.createdAt).toLocaleDateString('ar-SA')}
                        </TableCell>
                        <TableCell>
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button 
                                size="sm"
                                variant="outline"
                                className="border-gray-700 hover:bg-gray-800"
                              >
                                تحديث
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="bg-gray-900 border-gray-700">
                              <DialogHeader>
                                <DialogTitle className="text-white">تحديث حالة الطلب #{order.id}</DialogTitle>
                                <DialogDescription>
                                  اختر الحالة الجديدة للطلب
                                </DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4 py-4">
                                <div>
                                  <label className="text-white text-sm font-bold mb-2 block">الحالة الحالية</label>
                                  <p className={`px-3 py-2 rounded ${getStatusColor(order.status)}`}>
                                    {getStatusLabel(order.status)}
                                  </p>
                                </div>
                                <div>
                                  <label className="text-white text-sm font-bold mb-2 block">الحالة الجديدة</label>
                                  <Select 
                                    defaultValue={order.status}
                                    onValueChange={(value) => {
                                      handleStatusChange(order.id, value as any);
                                    }}
                                  >
                                    <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                                      <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent className="bg-gray-800 border-gray-700">
                                      <SelectItem value="new">جديد</SelectItem>
                                      <SelectItem value="in_progress">قيد التنفيذ</SelectItem>
                                      <SelectItem value="completed">مكتمل</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
