import { useState, useEffect } from 'react';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { Loader2, Check, Zap } from 'lucide-react';

export default function Storefront() {
  const [selectedService, setSelectedService] = useState<number | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [tiktokLink, setTiktokLink] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const servicesQuery = trpc.services.list.useQuery();
  const offersQuery = trpc.offers.list.useQuery();
  const createOrderMutation = trpc.orders.create.useMutation();

  const services = servicesQuery.data || [];
  const offers = offersQuery.data || [];

  const handleSubmitOrder = async () => {
    if (!selectedService || !customerName || !customerEmail || !tiktokLink) {
      toast.error('يرجى ملء جميع الحقول');
      return;
    }

    setIsSubmitting(true);
    try {
      const result = await createOrderMutation.mutateAsync({
        serviceId: selectedService,
        customerName,
        customerEmail,
        tiktokLink,
        quantity,
      });

      toast.success(`تم إنشاء الطلب بنجاح! رقم الطلب: ${result.orderId}`);
      
      // Reset form
      setSelectedService(null);
      setQuantity(1);
      setCustomerName('');
      setCustomerEmail('');
      setTiktokLink('');
    } catch (error) {
      toast.error('فشل في إنشاء الطلب');
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const selectedServiceData = services.find(s => s.id === selectedService);

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black">
      {/* Header */}
      <header className="border-b border-gray-800 bg-black/50 backdrop-blur">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white flex items-center gap-2">
                <Zap className="text-pink-500" size={32} />
                متجر خدمات تيك توك
              </h1>
              <p className="text-gray-400 mt-1">احصل على متابعين وتفاعلات حقيقية</p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        {/* Offers Section */}
        {offers.length > 0 && (
          <section className="mb-12">
            <h2 className="text-2xl font-bold text-white mb-6">العروض الخاصة</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {offers.map((offer) => (
                <Card key={offer.id} className="border-pink-500/50 bg-gradient-to-br from-pink-500/10 to-transparent">
                  <CardHeader>
                    <CardTitle className="text-pink-400">{offer.name}</CardTitle>
                    <CardDescription className="text-gray-300">{offer.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-pink-400">
                      خصم {offer.discountPercentage}%
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>
        )}

        {/* Services Grid */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">الخدمات المتاحة</h2>
          
          {servicesQuery.isLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="animate-spin text-pink-500" size={40} />
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
              {services.map((service) => (
                <Dialog key={service.id}>
                  <DialogTrigger asChild>
                    <Card 
                      className={`cursor-pointer transition-all hover:border-pink-500 hover:shadow-lg hover:shadow-pink-500/20 ${
                        selectedService === service.id 
                          ? 'border-pink-500 shadow-lg shadow-pink-500/30' 
                          : 'border-gray-700 bg-gray-900/50'
                      }`}
                      onClick={() => setSelectedService(service.id)}
                    >
                      <CardHeader>
                        <CardTitle className="text-lg text-white">{service.name}</CardTitle>
                        <CardDescription className="text-gray-400 text-sm line-clamp-2">
                          {service.description}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-end justify-between">
                          <div>
                            <p className="text-xs text-gray-500">السعر</p>
                            <p className="text-2xl font-bold text-pink-400">{service.price}</p>
                          </div>
                          <Check className="text-pink-500" size={20} />
                        </div>
                      </CardContent>
                    </Card>
                  </DialogTrigger>
                  
                  <DialogContent className="bg-gray-900 border-gray-700">
                    <DialogHeader>
                      <DialogTitle className="text-white">{service.name}</DialogTitle>
                      <DialogDescription className="text-gray-300">
                        {service.description}
                      </DialogDescription>
                    </DialogHeader>
                    
                    <div className="space-y-4 py-4">
                      <div>
                        <Label className="text-white">الكمية</Label>
                        <Input 
                          type="number" 
                          min={service.minQuantity} 
                          max={service.maxQuantity}
                          value={quantity}
                          onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
                          className="bg-gray-800 border-gray-700 text-white"
                        />
                        <p className="text-xs text-gray-400 mt-1">
                          من {service.minQuantity} إلى {service.maxQuantity}
                        </p>
                      </div>

                      <div>
                        <Label className="text-white">الاسم</Label>
                        <Input 
                          value={customerName}
                          onChange={(e) => setCustomerName(e.target.value)}
                          placeholder="أدخل اسمك"
                          className="bg-gray-800 border-gray-700 text-white"
                        />
                      </div>

                      <div>
                        <Label className="text-white">البريد الإلكتروني</Label>
                        <Input 
                          type="email"
                          value={customerEmail}
                          onChange={(e) => setCustomerEmail(e.target.value)}
                          placeholder="أدخل بريدك الإلكتروني"
                          className="bg-gray-800 border-gray-700 text-white"
                        />
                      </div>

                      <div>
                        <Label className="text-white">رابط حسابك على تيك توك</Label>
                        <Input 
                          type="url"
                          value={tiktokLink}
                          onChange={(e) => setTiktokLink(e.target.value)}
                          placeholder="https://www.tiktok.com/@yourprofile"
                          className="bg-gray-800 border-gray-700 text-white"
                        />
                      </div>

                      <div className="bg-gray-800 p-4 rounded-lg">
                        <p className="text-gray-400 text-sm">السعر الإجمالي</p>
                        <p className="text-2xl font-bold text-pink-400">
                          {service.price * quantity}
                        </p>
                      </div>

                      <Button 
                        onClick={handleSubmitOrder}
                        disabled={isSubmitting}
                        className="w-full bg-gradient-to-r from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700 text-white font-bold py-2"
                      >
                        {isSubmitting ? (
                          <>
                            <Loader2 className="animate-spin mr-2" size={18} />
                            جاري المعالجة...
                          </>
                        ) : (
                          'تأكيد الطلب'
                        )}
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              ))}
            </div>
          )}
        </section>

        {/* Info Section */}
        <section className="bg-gray-900/50 border border-gray-800 rounded-lg p-8 text-center">
          <h3 className="text-xl font-bold text-white mb-4">لماذا تختار خدماتنا؟</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <p className="text-pink-400 font-bold mb-2">متابعون حقيقيون</p>
              <p className="text-gray-400">جميع المتابعين والتفاعلات حقيقية وآمنة</p>
            </div>
            <div>
              <p className="text-pink-400 font-bold mb-2">سرعة التسليم</p>
              <p className="text-gray-400">نسلم الطلبات بسرعة وكفاءة عالية</p>
            </div>
            <div>
              <p className="text-pink-400 font-bold mb-2">دعم 24/7</p>
              <p className="text-gray-400">فريق دعم متاح طوال الوقت لمساعدتك</p>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
