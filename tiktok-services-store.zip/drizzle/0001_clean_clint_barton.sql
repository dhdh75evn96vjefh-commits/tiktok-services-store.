CREATE TABLE `offers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`discountPercentage` int NOT NULL,
	`serviceId` int,
	`startDate` timestamp NOT NULL,
	`endDate` timestamp NOT NULL,
	`googleSheetRow` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `offers_id` PRIMARY KEY(`id`),
	CONSTRAINT `offers_googleSheetRow_unique` UNIQUE(`googleSheetRow`)
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`serviceId` int NOT NULL,
	`customerName` varchar(255) NOT NULL,
	`customerEmail` varchar(320) NOT NULL,
	`tiktokLink` varchar(255) NOT NULL,
	`quantity` int NOT NULL,
	`totalPrice` int NOT NULL,
	`status` enum('new','in_progress','completed') NOT NULL DEFAULT 'new',
	`googleSheetRow` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `orders_id` PRIMARY KEY(`id`),
	CONSTRAINT `orders_googleSheetRow_unique` UNIQUE(`googleSheetRow`)
);
--> statement-breakpoint
CREATE TABLE `services` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`category` varchar(255),
	`price` int NOT NULL,
	`minQuantity` int NOT NULL DEFAULT 1,
	`maxQuantity` int NOT NULL DEFAULT 100000,
	`unit` varchar(50) NOT NULL DEFAULT 'quantity',
	`googleSheetRow` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `services_id` PRIMARY KEY(`id`),
	CONSTRAINT `services_googleSheetRow_unique` UNIQUE(`googleSheetRow`)
);
--> statement-breakpoint
ALTER TABLE `offers` ADD CONSTRAINT `offers_serviceId_services_id_fk` FOREIGN KEY (`serviceId`) REFERENCES `services`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `orders` ADD CONSTRAINT `orders_serviceId_services_id_fk` FOREIGN KEY (`serviceId`) REFERENCES `services`(`id`) ON DELETE no action ON UPDATE no action;